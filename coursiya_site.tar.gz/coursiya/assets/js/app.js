/* Coursiya – simple intelligence: client-side fuzzy search, trending, and recommendations. */
(function(){
  const state = {
    allCourses: [],
    filtered: [],
    categories: new Set(),
    userInteractions: JSON.parse(localStorage.getItem('crs_interactions')||'{}'),
    theme: localStorage.getItem('crs_theme') || 'light'
  };

  const $ = (sel, root=document) => root.querySelector(sel);
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  document.documentElement.setAttribute('data-theme', state.theme);

  const themeToggle = $('#themeToggle');
  if(themeToggle){
    themeToggle.textContent = state.theme === 'dark' ? '🌙' : '☀️';
    themeToggle.addEventListener('click', () => {
      state.theme = state.theme === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', state.theme);
      themeToggle.textContent = state.theme === 'dark' ? '🌙' : '☀️';
      localStorage.setItem('crs_theme', state.theme);
    });
  }

  const year = $('#year');
  if(year){ year.textContent = new Date().getFullYear(); }

  // Dummy course data
  const seedCourses = () => {
    const categories = ['Web Development','Data Science','Design','Marketing','AI/ML','Cloud'];
    const levels = ['beginner','intermediate','advanced'];
    const instructors = ['Alex Carter','Priya Nair','Mateo Diaz','Lina Park','Noah Smith','Aisha Khan'];
    const demo = [];
    const thumbs = [
      'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1529101091764-c3526daf38fe?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=1200&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1518773553398-650c184e0bb3?q=80&w=1200&auto=format&fit=crop'
    ];
    const titles = [
      'Modern Web Development',
      'Data Science Foundations',
      'UI/UX Design Essentials',
      'Digital Marketing Strategy',
      'Practical Machine Learning',
      'Cloud Fundamentals with AWS'
    ];
    for(let i=0;i<12;i++){
      const c = i % categories.length;
      const l = i % levels.length;
      demo.push({
        id: 'c'+(i+1),
        title: titles[c] + (i>5? ' II':''),
        category: categories[c],
        level: levels[l],
        price: (Math.floor(Math.random()*7)+9)*5, // 45-80
        rating: (Math.random()*1.2+3.8).toFixed(1),
        durationHours: Math.floor(Math.random()*10)+8,
        lessons: Math.floor(Math.random()*40)+40,
        instructor: instructors[i%instructors.length],
        thumbnail: thumbs[c],
        trending: Math.random()>0.5
      });
    }
    return demo;
  };

  const coursesGrid = $('#coursesGrid');
  const categoryFilter = $('#categoryFilter');
  const levelFilter = $('#levelFilter');
  const sortBy = $('#sortBy');
  const searchInput = $('#searchInput');
  const searchBtn = $('#searchBtn');
  const categoryPills = $('#categoryPills');
  const quickPills = $('#quickPills');

  function renderCourses(list){
    if(!coursesGrid) return;
    coursesGrid.innerHTML = '';
    list.forEach(course => {
      const el = document.createElement('article');
      el.className = 'card';
      el.innerHTML = `
        <img class="thumb" src="${course.thumbnail}" alt="${course.title}">
        <div class="content">
          <span class="badge">${course.category}</span>
          <h3 class="title">${course.title}</h3>
          <p class="muted">${course.level[0].toUpperCase()+course.level.slice(1)} • ${course.durationHours}h • ${course.lessons} lessons</p>
          <div class="price-row">
            <div class="muted">⭐ ${course.rating}</div>
            <div class="price">$${course.price}</div>
          </div>
        </div>`;
      el.addEventListener('click', () => {
        registerInteraction('view', course);
        highlightRecommendations();
      });
      coursesGrid.appendChild(el);
    });
  }

  function fuzzyIncludes(hay, needle){
    hay = hay.toLowerCase();
    needle = needle.toLowerCase();
    if(hay.includes(needle)) return true;
    let i=0; // simple subsequence match
    for(const ch of hay){ if(ch===needle[i]) i++; if(i===needle.length) return true; }
    return false;
  }

  function applyFilters(){
    const q = (searchInput?.value || '').trim();
    const cat = categoryFilter?.value || 'all';
    const lvl = levelFilter?.value || 'all';
    let list = [...state.allCourses];
    if(cat !== 'all') list = list.filter(c=>c.category===cat);
    if(lvl !== 'all') list = list.filter(c=>c.level===lvl);
    if(q){
      list = list.filter(c => fuzzyIncludes(c.title+' '+c.instructor+' '+c.category, q));
    }
    const sort = sortBy?.value || 'trending';
    if(sort==='rating') list.sort((a,b)=>Number(b.rating)-Number(a.rating));
    if(sort==='price_asc') list.sort((a,b)=>a.price-b.price);
    if(sort==='price_desc') list.sort((a,b)=>b.price-a.price);
    if(sort==='trending') list.sort((a,b)=>Number(b.trending)-Number(a.trending));
    state.filtered = list;
    renderCourses(list);
  }

  function populateFilters(){
    state.categories.forEach(cat => {
      const opt = document.createElement('option');
      opt.value = cat; opt.textContent = cat; categoryFilter?.appendChild(opt);
      const pill = document.createElement('button');
      pill.className = 'pill'; pill.textContent = cat; pill.addEventListener('click',()=>{
        if(categoryFilter){ categoryFilter.value = cat; applyFilters(); }
      });
      categoryPills?.appendChild(pill);
    });
  }

  function registerInteraction(kind, course){
    const key = course.category;
    state.userInteractions[key] = (state.userInteractions[key]||0) + (kind==='view'? 2 : 1);
    localStorage.setItem('crs_interactions', JSON.stringify(state.userInteractions));
  }

  function highlightRecommendations(){
    // Build quick pills from interactions
    const items = Object.entries(state.userInteractions).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([label])=>label);
    quickPills.innerHTML = '';
    const base = items.length? items : ['Web Development','Data Science','AI/ML'];
    base.forEach(t => {
      const pill = document.createElement('button'); pill.className='pill'; pill.textContent = t; pill.addEventListener('click',()=>{
        if(categoryFilter){ categoryFilter.value = t; applyFilters(); }
      });
      quickPills.appendChild(pill);
    });
  }

  function initNewsletter(){
    const form = document.getElementById('newsletterForm');
    const email = document.getElementById('newsletterEmail');
    const msg = document.getElementById('newsletterMsg');
    if(!form) return;
    form.addEventListener('submit', (e)=>{
      e.preventDefault();
      if(!email.value || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email.value)){
        msg.textContent = 'Please enter a valid email.'; msg.style.color = '#e11d48'; return;
      }
      msg.textContent = 'Thanks! You are on the list.'; msg.style.color = 'var(--brand)';
      email.value = '';
    });
  }

  // Bootstrap
  state.allCourses = seedCourses();
  state.allCourses.forEach(c => state.categories.add(c.category));
  populateFilters();
  applyFilters();
  highlightRecommendations();
  initNewsletter();
})();

