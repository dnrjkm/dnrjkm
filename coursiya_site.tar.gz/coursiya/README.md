# Coursiya

A modern, responsive course catalog landing page built with HTML, CSS, and JavaScript.

- Primary color: `#3f8dfb`
- Logo: `assets/img/logo.svg`
- Dummy courses with client-side search, filters, and lightweight recommendations

## Develop

Open `index.html` in a browser or use any static server.

## Deploy

This project is static and can be hosted on any static host. A GitHub Actions workflow for Pages is included.

## License

MIT